#include <stdio.h>

int main() {
    int age, remaining_years;

    printf("Enter your age: ");
    scanf("%d", &age);

    if (age >= 18) {
        printf("You are eligible to vote.\n");
    } else {
        remaining_years = 18 - age;
        printf("You are not eligible to vote.\n");
        printf("You need to wait for %d more years to become eligible to vote.\n", remaining_years);
    }

    return 0;
}
