#include <stdio.h>
#include <math.h>

float power(int x, int n) {
    return pow(x, n);
}

float addition(int x, int n) {
    return x + n;
}

float subtraction(int x, int n) {
    return x - n;
}

float multiplication(int x, int n) {
    return x * n;
}

float division(int x, int n) {
    return (float) x / n;
}

int main() {
    int x, n, choice;
    float result;
    printf("Enter x and n: ");
    scanf("%d%d", &x, &n);
    printf("Enter operation to perform:\n");
    printf("1. Power\n");
    printf("2. Addition\n");
    printf("3. Subtraction\n");
    printf("4. Multiplication\n");
    printf("5. Division\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);
    switch (choice) {
        case 1:
            result = power(x, n);
            printf("%d^%d = %f", x, n, result);
            break;
        case 2:
            result = addition(x, n);
            printf("%d + %d = %f", x, n, result);
            break;
        case 3:
            result = subtraction(x, n);
            printf("%d - %d = %f", x, n, result);
            break;
        case 4:
            result = multiplication(x, n);
            printf("%d * %d = %f", x, n, result);
            break;
        case 5:
            result = division(x, n);
            printf("%d / %d = %f", x, n, result);
            break;
        default:
            printf("Invalid choice!");
    }
    return 0;
}
