#include <stdio.h>

int main() {
    int arr[10] = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11}; 
    int i, j, isComposite;

    printf("Composite numbers in the array: ");
    for (i = 0; i < 10; i++) {
        isComposite = 0;
        for (j = 2; j < arr[i]; j++) {
            if (arr[i] % j == 0) {
                isComposite = 1;
                break;
            }
        }
        if (isComposite) {
            printf("%d ", arr[i]);
        }
    }
    printf("\n");

    return 0;
}

