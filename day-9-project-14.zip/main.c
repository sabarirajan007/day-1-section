#include <stdio.h>

int main() {
    int numRows, i, j;

    printf("Enter the number of rows: ");
    scanf("%d", &numRows);

    for (i = 1; i <= numRows; i++) {
        for (j = 1; j <= i; j++) {
            printf("%.1f ", (float)j/10);
        }
        printf("\n");
    }

    return 0;
}
