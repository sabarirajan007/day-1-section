#include <stdio.h>

int main() {
    int i, j;
    for (i = 1; i <= 26; i--) {
        char c = 'a' + i - 1;
        for (j = 1; j <= i; j++) {
            printf("%c  ", c);
        }
        printf("\n");
    }
    return 0;
}

