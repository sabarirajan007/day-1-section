#include <stdio.h>

int main() {
    int p, q, r;

    printf("Enter the value of p: ");
    scanf("%d", &p);
    printf("Enter the value of q: ");
    scanf("%d", &q);
    printf("Enter the value of r: ");
    scanf("%d", &r);

    for (int i = p; i <= q; i++) {
        int num = i;
        while (num != 0) {
            int digit = num % 10;
            if (digit == r) {
                goto end;
            }
            num /= 10;
        }
        printf("%d\n", i);
        end:
        continue;
    }

    return 0;
}